# dot-claude

> A powerful configuration framework for Claude Code that enables custom agents, slash commands, and project-wide development standards through shareable .claude directories

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)]()
[![Claude Code](https://img.shields.io/badge/Claude%20Code-Compatible-purple.svg)]()
[![Python 3.11+](https://img.shields.io/badge/Python-3.11%2B-blue.svg)]()

**dot-claude** is a comprehensive configuration and automation framework for Claude Code that brings the power of custom agents, slash commands, and constitutional development principles to your projects. Think of it as a dotfiles system for AI-assisted development - shareable, versionable, and project-specific.

## Features

- **Custom Agents**: Pre-built specialist agents for code review, documentation generation, testing, and more
- **Slash Commands**: Quick-access commands for common development workflows
- **Constitutional Development**: Enforce project-specific coding standards and principles automatically
- **Project Sync**: Deploy configurations across multiple projects with a single command
- **Zero Dependencies**: Pure markdown-based configuration that works seamlessly with Claude Code
- **Version Controlled**: Keep your AI workflows in git alongside your code

## Table of Contents

- [What is dot-claude?](#what-is-dot-claude)
- [Quick Start](#quick-start)
- [Installation](#installation)
- [Configuration](#configuration)
- [Available Agents](#available-agents)
- [Available Commands](#available-commands)
- [The Constitution](#the-constitution)
- [Syncing to Projects](#syncing-to-projects)
- [Creating Custom Agents](#creating-custom-agents)
- [Creating Custom Commands](#creating-custom-commands)
- [Project Structure](#project-structure)
- [Development](#development)
- [Contributing](#contributing)
- [License](#license)

## What is dot-claude?

dot-claude provides a `.claude` directory structure that configures Claude Code with:

1. **Specialized Agents** - Expert systems focused on specific tasks (code review, documentation, testing)
2. **Slash Commands** - Quick shortcuts for common operations (`/commit`, `/code-review`, `/generate-readme`)
3. **Development Constitution** - Non-negotiable coding principles enforced across your projects
4. **Project Settings** - Permissions, integrations, and tool configurations

This enables:
- Consistent code quality across teams and projects
- Automated enforcement of coding standards
- Rapid context switching between different types of work
- Shareable AI workflows that travel with your code

## Quick Start

```bash
# Clone the repository
git clone https://github.com/yourusername/dot-claude.git
cd dot-claude

# Install to your Claude Code user directory
make install-claude-user-folder

# Or sync to specific projects
echo "/path/to/your/project/.claude" >> targets.txt
make sync-to-targets
```

Now you can use commands like `/commit`, `/code-review`, or invoke agents directly!

## Installation

### Option 1: User-Level Installation

Install agents and commands to your user-level Claude Code directory:

```bash
make install-claude-user-folder
```

This copies all agents and commands to `~/.claude/`, making them available across all your projects.

### Option 2: Project-Level Installation

For project-specific configurations:

```bash
# Copy the .claude directory to your project
cp -r .claude /path/to/your/project/

# Or add your project to targets and sync
echo "/path/to/your/project/.claude" >> targets.txt
make sync-to-targets
```

### Option 3: Multi-Project Sync

Manage multiple projects with automatic syncing:

```bash
# Add project paths to targets.txt (one per line)
/Users/you/project1/.claude
/Users/you/project2/.claude
/Users/you/project3/.claude

# Sync constitution, agents, and commands to all targets
make sync-to-targets
```

## Configuration

### Settings File

Create or modify `settings.json` in your `.claude` directory:

```json
{
  "permissions": {
    "allow": [
      "Bash(git:*)",
      "Bash(python:*)",
      "Bash(make:*)"
    ],
    "deny": [],
    "defaultMode": "acceptEdits"
  },
  "dotClaude": {
    "constitutionUrl": "@.claude/constitution.md",
    "description": "Custom configuration for your project"
  }
}
```

### Constitution URL

The constitution is referenced in settings and enforced across all agents. Update all references:

```bash
make update-constitution
```

## Available Agents

dot-claude includes powerful specialist agents that handle specific development tasks:

| Agent | Purpose | Use Case |
|-------|---------|----------|
| **agent-generator** | Creates new custom agents | Generate specialized agents for your needs |
| **claude-md-generator** | Generates CLAUDE.md documentation | Document folder structures and components |
| **claude-md-updater** | Updates existing CLAUDE.md files | Keep documentation in sync with code |
| **code-reviewer** | Comprehensive code quality review | Pre-merge code review and quality checks |
| **commit-agent** | Intelligent commit message generation | Generate conventional commit messages |
| **constitution-task-generator** | Creates tasks based on constitution | Plan work aligned with coding principles |
| **constitution-task-executor** | Executes constitutional tasks | Implement tasks following standards |
| **pydantic-refactor-specialist** | Refactors code to use Pydantic models | Modernize Python code with type safety |
| **readme-generator** | Creates comprehensive README files | Generate GitHub-ready documentation |
| **schema-generator** | Generates data schemas | Create Pydantic/dataclass models |
| **slash-command-generator** | Creates custom slash commands | Build your own command shortcuts |

### Agent Usage

Agents are invoked automatically by Claude Code based on context, or explicitly:

```markdown
Please use the code-reviewer agent to review my recent changes.
```

Or invoke via Task delegation in custom commands.

## Available Commands

Quick-access slash commands for common workflows:

| Command | Description | Usage |
|---------|-------------|-------|
| `/code-review` | Review current branch changes | `/code-review` |
| `/commit` | Auto-commit with smart messages | `/commit` |
| `/execute-tasks` | Execute constitutional tasks | `/execute-tasks` |
| `/format-md` | Format markdown files | `/format-md [file]` |
| `/generate-agent` | Create a new agent | `/generate-agent "description"` |
| `/generate-claude-md` | Generate CLAUDE.md | `/generate-claude-md [path]` |
| `/generate-command` | Create a new command | `/generate-command "description"` |
| `/generate-mr-doc` | Generate merge request docs | `/generate-mr-doc` |
| `/generate-readme` | Generate README.md | `/generate-readme [path]` |
| `/generate-tasks` | Generate tasks from constitution | `/generate-tasks` |
| `/pythonic-refactor` | Refactor Python code | `/pythonic-refactor [path]` |

### Command Usage

Simply type the slash command in your Claude Code conversation:

```
/commit
```

Many commands accept optional arguments:

```
/generate-readme src/my-library
```

## The Constitution

The `constitution.md` file defines non-negotiable development principles enforced across your codebase:

### Core Principles

1. **Radical Simplicity** - Always implement the simplest solution
2. **Fail Fast Philosophy** - Systems should fail immediately when assumptions are violated
3. **Comprehensive Type Safety** - Use type hints everywhere possible
4. **Structured Data Models** - Always use dataclasses or Pydantic models
5. **Unit Testing with Mocking** - Appropriate test coverage without over-engineering
6. **Dependency Injection** - All services use constructor injection (required parameters only)
7. **SOLID Principles** - Strictly adhere to SOLID design principles

### Example Enforcement

The constitution is referenced by agents and commands to ensure:
- Code reviews check for complexity violations
- Generated code follows type safety requirements
- Refactoring tools apply dependency injection patterns
- All work aligns with established principles

### Customizing the Constitution

Edit `.claude/constitution.md` to match your team's standards, then sync:

```bash
make update-constitution
make sync-to-targets
```

## Syncing to Projects

dot-claude includes powerful syncing capabilities for managing multiple projects:

### The targets.txt File

List target project `.claude` directories:

```
/Users/brandon/code/projects/project1/.claude
/Users/brandon/code/projects/project2/.claude
/Users/brandon/code/projects/project3/.claude
```

### Sync Command

Deploy constitution, agents, commands, and scripts to all targets:

```bash
make sync-to-targets
```

This uses the Python sync utility:

```bash
# Or run directly with uv
uv run ./src/sync_to_targets.py
```

### What Gets Synced

- `constitution.md` - Development principles
- `agents/` - All agent definitions
- `commands/` - All slash commands
- `scripts/` - Utility scripts (if present)

### Sync Workflow

```bash
# 1. Update your main dot-claude configuration
vim .claude/constitution.md
vim .claude/agents/my-agent.md

# 2. Sync to all projects
make sync-to-targets

# 3. Commit in each project
cd /path/to/project1
git add .claude/
git commit -m "Update dot-claude configuration"
```

## Creating Custom Agents

Generate new agents using the agent generator:

```bash
/generate-agent "database query optimizer that analyzes SQL performance"
```

Or create manually in `.claude/agents/`:

```markdown
---
name: my-custom-agent
description: Expert at doing specific task. Use when...
tools: Read, Write, Grep, Bash
model: us.anthropic.claude-sonnet-4-5-20250929-v1:0
---

You are an expert at [specific domain].

## Your Role
[Clear role definition]

## Process
1. [Step-by-step workflow]
2. [Quality standards]
3. [Output requirements]

## Example Usage
[Concrete examples]
```

### Agent Best Practices

- **Single Responsibility** - One clear purpose per agent
- **Specific Triggers** - Clear description of when to invoke
- **Minimal Tools** - Only grant necessary tool access
- **Detailed Instructions** - Comprehensive system prompts
- **Constitution Alignment** - Reference constitution for standards

## Creating Custom Commands

Generate new commands using the command generator:

```bash
/generate-command "run integration tests with coverage report"
```

Or create manually in `.claude/commands/`:

```markdown
---
name: my-command
description: What this command does
argument-hint: "[optional args]"
allowed-tools: Task, Read, Bash
---

Brief description of the command.

## Usage
\`\`\`bash
/my-command [args]
\`\`\`

## Steps

### 1. Validate Input
[Input validation logic]

### 2. Execute Action
[Step-by-step process]

### 3. Report Results
[Output format and confirmation]
```

### Command Best Practices

- **Clear Arguments** - Document expected arguments
- **Validation** - Validate inputs before execution
- **Feedback** - Provide clear success/failure messages
- **Tool Restrictions** - Use `allowed-tools` for security
- **Agent Delegation** - Leverage Task tool for complex operations

## Project Structure

```
dot-claude/
├── .claude/                    # Main configuration directory
│   ├── constitution.md         # Development principles (non-negotiable)
│   ├── settings.local.json     # Local environment settings
│   ├── agents/                 # Specialized AI agents
│   │   ├── agent-generator.md
│   │   ├── code-reviewer.md
│   │   ├── readme-generator.md
│   │   └── ...
│   └── commands/               # Slash commands
│       ├── commit.md
│       ├── code-review.md
│       ├── generate-readme.md
│       └── ...
├── src/
│   └── sync_to_targets.py     # Multi-project sync utility
├── targets.txt                 # Project sync destinations
├── settings.json               # User-level settings template
├── Makefile                    # Installation and management commands
├── .gitignore                  # Git ignore patterns
└── README.md                   # This file
```

## Development

### Prerequisites

- Claude Code (latest version)
- Python 3.11+ (for sync utility)
- Git (for version control)
- Make (for build automation)

### Setup

```bash
# Clone the repository
git clone https://github.com/yourusername/dot-claude.git
cd dot-claude

# Install locally for testing
make install-claude-user-folder

# Test sync functionality
echo "/tmp/test-project/.claude" >> targets.txt
make sync-to-targets
```

### Common Development Tasks

```bash
# Install agents and commands
make install-claude-user-folder

# Uninstall
make uninstall

# Update constitution URLs
make update-constitution

# Sync to projects
make sync-to-targets

# Clean backup files
make clean

# Show available commands
make help
```

### Testing Changes

1. Modify agents or commands in `.claude/`
2. Test locally by invoking commands or agents
3. Sync to test projects: `make sync-to-targets`
4. Verify functionality in target projects
5. Commit and push changes

## Contributing

We welcome contributions! Here's how to get involved:

### Contribution Workflow

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/amazing-agent`
3. Make your changes (add agents, commands, improve docs)
4. Test thoroughly with real projects
5. Commit with clear messages: `git commit -m 'Add amazing agent for X'`
6. Push to your fork: `git push origin feature/amazing-agent`
7. Open a Pull Request

### Contribution Ideas

- **New Agents** - Domain-specific specialists (DevOps, security, performance)
- **New Commands** - Workflow automation shortcuts
- **Documentation** - Tutorials, examples, best practices
- **Constitution Examples** - Alternative coding philosophies
- **Sync Improvements** - Enhanced multi-project management
- **Integration Examples** - Sample projects using dot-claude

### Code Standards

All contributions should:
- Follow the patterns of existing agents and commands
- Include clear documentation and examples
- Use proper YAML frontmatter formatting
- Test with real-world scenarios
- Align with the constitutional principles (or document deviations)

## FAQ

### How is this different from .clinerules?

dot-claude is specifically designed for Claude Code's `.claude` directory structure and takes full advantage of its agent and command systems. It's more comprehensive than simple rule files.

### Can I customize the constitution for my team?

Absolutely! Edit `.claude/constitution.md` to reflect your team's standards, then sync to all projects.

### Do agents work across programming languages?

Yes! While some agents are Python-focused (like pydantic-refactor-specialist), most agents (code-reviewer, readme-generator, etc.) work with any language.

### How do I share my custom agents?

Commit your `.claude` directory to git and share the repository. Others can sync to their projects using the targets.txt approach.

### Can I use only some agents/commands?

Yes! You can selectively copy agents or commands, or remove unwanted ones from the directories.

### What if I want different constitutions per project?

Keep project-specific constitutions in each project's `.claude/constitution.md` and don't sync the constitution file.

## Roadmap

- [ ] Agent templates for additional domains (frontend, mobile, data science)
- [ ] Interactive command builder for complex workflows
- [ ] Constitution validator to check code compliance
- [ ] VS Code extension for easier management
- [ ] Community agent marketplace
- [ ] Multi-language constitution examples
- [ ] Automated testing framework for agents

## Support

- **Issues**: Report bugs or request features via [GitHub Issues](https://github.com/yourusername/dot-claude/issues)
- **Discussions**: Join conversations in [GitHub Discussions](https://github.com/yourusername/dot-claude/discussions)
- **Documentation**: Additional guides in the [Wiki](https://github.com/yourusername/dot-claude/wiki)

## Acknowledgments

- Built for the [Claude Code](https://docs.anthropic.com/en/docs/developer-tools/claude-code) platform by Anthropic
- Inspired by dotfiles culture and Infrastructure as Code principles
- Thanks to all contributors and the Claude Code community

## License

MIT License - see LICENSE file for details

---

**Built with Claude Code** | [Documentation](https://docs.anthropic.com/en/docs/developer-tools/claude-code) | [Report Issues](https://github.com/yourusername/dot-claude/issues) | [Contribute](CONTRIBUTING.md)
